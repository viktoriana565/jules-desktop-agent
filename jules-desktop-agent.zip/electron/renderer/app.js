// DOM Elements
const elements = {
    titlebar: document.getElementById('titlebar'),
    sidebar: document.getElementById('sidebar'),
    chatArea: document.getElementById('chat-area'),
    messages: document.getElementById('messages'),
    taskInput: document.getElementById('task-input'),
    sendBtn: document.getElementById('send-btn'),
    settingsBtn: document.getElementById('settings-btn'),
    settingsPanel: document.getElementById('settings-panel'),
    closeSettings: document.getElementById('close-settings'),
    saveSettingsBtn: document.getElementById('save-settings-btn'),
    minimizeBtn: document.getElementById('minimize-btn'),
    closeBtn: document.getElementById('close-btn'),
    repoSelector: document.getElementById('repo-custom-select'),
    repoSelected: document.getElementById('repo-selected'),
    repoOptions: document.getElementById('repo-options'),
    branchSelector: document.getElementById('branch-custom-select'),
    branchSelected: document.getElementById('branch-selected'),
    branchOptions: document.getElementById('branch-options'),
    refreshRepos: document.getElementById('refresh-repos'),
    sessionsList: document.getElementById('sessions-list'),
    progress: document.getElementById('progress'),
    progressText: document.getElementById('progress-text'),
    confirmPlanBtn: document.getElementById('confirm-plan-btn'),
    apiKeyInput: document.getElementById('api-key-input'),
    outputDirInput: document.getElementById('output-dir-input'),
    themeSelector: document.getElementById('theme-selector'),
    confirmPlanToggle: document.getElementById('confirm-plan-toggle'),
    autoPrToggle: document.getElementById('auto-pr-toggle')
};

// Application State
const state = {
    currentSourceId: null,
    currentBranch: 'main',
    currentSessionId: null,
    closeStream: null,      // SSE close handle (replaces pollingTimer)
    sessions: [],
    sources: [],
    config: {},
    isReady: false,
    displayedActivityIds: new Set()
};

// Activity type → emoji icon mapping for the live log
const ACTIVITY_ICONS = {
    planStep:       '📋',
    planGenerated:  '📋',
    codeEdit:       '✏️',
    fileCreated:    '📄',
    testRun:        '🧪',
    commitCreated:  '💾',
    prCreated:      '🔗',
    agentMessaged:  '💬',
    agentMessage:   '💬',
    userMessaged:   '👤',
    progressUpdated:'⚡',
    sessionCompleted:'✅',
    sessionFailed:  '❌',
};


// Initialize
async function init() {
    // Setup basic listeners immediately
    setupEventListeners();
    setupDropdownClosing();

    try {
        // Wait for backend to be ready
        await waitForBackend();
        
        // Load data in parallel
        const [config] = await Promise.all([
            window.julesAPI.getConfig(),
            loadSources(),
            loadSessions()
        ]);
        
        state.config = config;
        applyConfig(state.config);
        
        state.isReady = true;
        updateSendButtonState();
        
    } catch (error) {
        console.error('Initialization error:', error);
        addMessage('jules', 'Ошибка инициализации. Проверьте подключение к бэкенду.');
    }
}

async function waitForBackend(attempts = 50) {
    for (let i = 0; i < attempts; i++) {
        const ok = await window.julesAPI.checkBackend();
        if (ok) return true;
        await new Promise(r => setTimeout(r, 200));
    }
    throw new Error('Backend not responding');
}

function applyConfig(config) {
    elements.apiKeyInput.value = config.jules_api_key || '';
    elements.outputDirInput.value = config.output_dir || '';
    elements.themeSelector.value = config.theme || 'dark';
    elements.confirmPlanToggle.checked = config.confirm_plan_before_execution;
    elements.autoPrToggle.checked = config.auto_create_pr;
    document.documentElement.setAttribute('data-theme', config.theme || 'dark');
}

function setupDropdownClosing() {
    document.addEventListener('click', () => {
        document.querySelectorAll('.options-dropdown').forEach(d => d.classList.add('hidden'));
        document.querySelectorAll('.input-selector-group').forEach(g => g.classList.remove('open'));
    });
}

async function loadSources() {
    try {
        const sources = await window.julesAPI.getSources();
        state.sources = sources;
        
        renderDropdownOptions(elements.repoOptions, sources.map(s => ({
            id: s.id,
            label: s.name
        })), (id) => {
            state.currentSourceId = id;
            const source = sources.find(s => s.id === id);
            elements.repoSelected.textContent = source.name;
            onRepoChange(source);
        });

        // Set initial state from config
        if (state.config.last_source_id) {
            const lastSource = sources.find(s => s.id === state.config.last_source_id);
            if (lastSource) {
                state.currentSourceId = lastSource.id;
                elements.repoSelected.textContent = lastSource.name;
                onRepoChange(lastSource);
            }
        }
    } catch (e) {
        console.error('Failed to load sources:', e);
    }
}

function renderDropdownOptions(container, items, onSelect) {
    container.innerHTML = '';
    items.forEach(item => {
        const div = document.createElement('div');
        div.className = 'option-item';
        if (item.id === state.currentSourceId || item.id === state.currentBranch) {
            div.classList.add('selected');
        }
        div.textContent = item.label;
        div.onclick = (e) => {
            e.stopPropagation();
            onSelect(item.id);
            container.classList.add('hidden');
            container.closest('.input-selector-group').classList.remove('open');
        };
        container.appendChild(div);
    });
}

function onRepoChange(source) {
    const branchGroup = document.getElementById('branch-selector-group');
    branchGroup.classList.remove('disabled');
    
    const branches = source.branches || ['main'];
    state.currentBranch = source.default_branch || branches[0];
    elements.branchSelected.textContent = state.currentBranch;

    renderDropdownOptions(elements.branchOptions, branches.map(b => ({
        id: b,
        label: b
    })), (branchId) => {
        state.currentBranch = branchId;
        elements.branchSelected.textContent = branchId;
        updateSendButtonState();
    });

    updateSendButtonState();
}

async function loadSessions() {
    try {
        state.sessions = await window.julesAPI.getSessions();
        renderSessionsList();
    } catch (e) {
        console.error('Failed to load sessions:', e);
    }
}

function renderSessionsList() {
    elements.sessionsList.innerHTML = '';
    state.sessions.forEach(session => {
        const item = document.createElement('div');
        item.className = `session-item ${state.currentSessionId === session.id ? 'active' : ''}`;
        
        const date = new Date(session.created_at).toLocaleDateString();
        
        item.innerHTML = `
            <div class="prompt">${session.prompt}</div>
            <div class="meta">
                <span>${session.status}</span>
                <span>${date}</span>
            </div>
        `;
        
        item.onclick = () => selectSession(session.id);
        elements.sessionsList.appendChild(item);
    });
}

async function selectSession(sessionId) {
    state.currentSessionId = sessionId;
    renderSessionsList();
    
    // Clear chat immediately
    elements.messages.innerHTML = '';
    state.displayedActivityIds.clear();
    
    // Find basic info from pre-loaded list for optimistic rendering
    const cachedSession = state.sessions.find(s => s.id === sessionId);
    if (cachedSession) {
        addMessage('user', cachedSession.prompt || 'Задача без описания');
    }

    // Load session details first (this triggers file export on backend)
    const isFinished = cachedSession && ['sessionCompleted', 'sessionFailed'].includes(cachedSession.status);

    try {
        const session = await window.julesAPI.getSession(sessionId);

        console.log(`Session ${sessionId} loaded`, session);
        
        // Render all activities
        if (session.activities && session.activities.length > 0) {
            session.activities.forEach(act => {
                const actId = act.name || JSON.stringify(act);
                if (!state.displayedActivityIds.has(actId)) {
                    let msg = act.message || 
                              act.text || 
                              (act.agentMessaged && act.agentMessaged.agentMessage) ||
                              (act.userMessaged && act.userMessaged.userMessage) ||
                              (act.sessionCompleted && act.sessionCompleted.message) ||
                              (act.progressUpdated && (act.progressUpdated.message || act.progressUpdated.description)) ||
                              act.description;
                                
                    if (msg) {
                        const role = act.originator === 'user' ? 'user' : 'jules';
                        addMessage(role, msg);
                        state.displayedActivityIds.add(actId);
                    } else if (act.planGenerated && act.planGenerated.plan) {
                        const role = act.originator === 'user' ? 'user' : 'jules';
                        addMessage(role, null, act.planGenerated.plan);
                        state.displayedActivityIds.add(actId);
                    }
                }
            });
        }
        
        updateStatusUI(session);
        
        // Load artifacts AFTER session data (export may have extracted new files)
        const artifacts = isFinished ? await window.julesAPI.getArtifacts(sessionId) : [];
        if (artifacts && artifacts.length > 0) {
            renderArtifacts(artifacts);
        }
        
        // If still active, start SSE streaming instead of polling
        if (!['sessionCompleted', 'sessionFailed'].includes(session.status)) {
            startStreaming(sessionId);
        } else {
            stopStreaming();
            elements.progress.classList.add('hidden');
        }
    } catch (e) {
        console.error('Failed to select session:', e);
    }
}

function setupEventListeners() {
    elements.newChatBtn = document.getElementById('new-chat-btn');
    elements.newChatBtn.onclick = createNewChat;

    elements.sendBtn.onclick = sendTask;
    
    elements.taskInput.oninput = () => {
        updateSendButtonState();
        autoResizeTextarea();
    };
    
    elements.taskInput.onkeydown = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendTask();
        }
    };

    elements.settingsBtn.onclick = () => elements.settingsPanel.classList.toggle('hidden');
    elements.closeSettings.onclick = () => elements.settingsPanel.classList.add('hidden');
    
    elements.saveSettingsBtn.onclick = saveSettings;
    
    const browseBtn = document.getElementById('browse-output-btn');
    if (browseBtn) {
        browseBtn.onclick = async () => {
            const folder = await window.julesAPI.selectFolder();
            if (folder) elements.outputDirInput.value = folder;
        };
    }
    
    elements.minimizeBtn.onclick = () => window.julesAPI.minimizeWindow();
    elements.closeBtn.onclick = () => window.julesAPI.closeWindow();
    
    elements.refreshRepos.onclick = loadSources;
    
    // Custom Dropdown Toggles
    elements.repoSelected.onclick = (e) => {
        e.stopPropagation();
        const wasHidden = elements.repoOptions.classList.contains('hidden');
        document.querySelectorAll('.options-dropdown').forEach(d => d.classList.add('hidden'));
        document.querySelectorAll('.input-selector-group').forEach(g => g.classList.remove('open'));
        if (wasHidden) {
            elements.repoOptions.classList.remove('hidden');
            elements.repoSelector.closest('.input-selector-group').classList.add('open');
        }
    };

    elements.branchSelected.onclick = (e) => {
        e.stopPropagation();
        const wasHidden = elements.branchOptions.classList.contains('hidden');
        document.querySelectorAll('.options-dropdown').forEach(d => d.classList.add('hidden'));
        document.querySelectorAll('.input-selector-group').forEach(g => g.classList.remove('open'));
        if (wasHidden) {
            elements.branchOptions.classList.remove('hidden');
            elements.branchSelector.closest('.input-selector-group').classList.add('open');
        }
    };

    elements.confirmPlanBtn.onclick = async () => {
        if (state.currentSessionId) {
            await window.julesAPI.confirmPlan(state.currentSessionId);
            elements.confirmPlanBtn.classList.add('hidden');
            elements.progressText.textContent = 'План подтвержден, Jules работает...';
        }
    };

    window.julesAPI.onFocusInput(() => {
        elements.taskInput.focus();
    });
}

function updateSendButtonState() {
    const hasText = !!elements.taskInput.value.trim();
    const canCreateNew = !state.currentSessionId && !!state.currentSourceId;
    const canFollowup = state.currentSessionId && canSendMessage(state.currentSessionStatus);
    
    elements.sendBtn.disabled = !state.isReady || !hasText || !(canCreateNew || canFollowup);
}

function canSendMessage(status) {
    if (!status) return false;
    const s = status.toLowerCase();
    return ['completed', 'sessioncompleted', 'awaiting_user_feedback', 'waitingforuserinput'].includes(s);
}

function createNewChat() {
    stopStreaming();
    state.currentSessionId = null;
    state.currentSessionStatus = null;
    elements.messages.innerHTML = `
        <div class="empty-state">
            <h3>Новая сессия</h3>
            <p>Выберите репозиторий и опишите новую задачу для Jules.</p>
        </div>
    `;
    elements.taskInput.value = '';
    elements.progress.classList.add('hidden');
    elements.confirmPlanBtn.classList.add('hidden');
    const actLog = document.getElementById('activity-log');
    if (actLog) actLog.innerHTML = '';
    autoResizeTextarea();
    
    // De-select items in sidebar
    document.querySelectorAll('.session-item').forEach(item => item.classList.remove('active'));
}

function autoResizeTextarea() {
    elements.taskInput.style.height = 'auto';
    elements.taskInput.style.height = elements.taskInput.scrollHeight + 'px';
}

async function sendTask() {
    const prompt = elements.taskInput.value.trim();
    if (!prompt || !state.currentSourceId) return;
    
    elements.taskInput.value = '';
    autoResizeTextarea();
    updateSendButtonState();
    
    // We only create a new session if state.currentSessionId is null or we cannot followup
    const isContinuing = state.currentSessionId && canSendMessage(state.currentSessionStatus);
    
    if (!isContinuing) {
        elements.messages.innerHTML = '';
    }
    
    addMessage('user', prompt);
    elements.progress.classList.remove('hidden');
    
    try {
        if (isContinuing) {
            elements.progressText.textContent = 'Продолжаем сессию...';
            elements.confirmPlanBtn.classList.add('hidden');
            
            // Send the message — even if it fails, we start streaming below
            try {
                await window.julesAPI.sendMessage(state.currentSessionId, prompt);
            } catch (sendErr) {
                console.warn('sendMessage error (will still stream):', sendErr.message);
                // Don't show error to user — the SSE stream will show the actual status
            }
            
            // ALWAYS start streaming for existing sessions
            // afterSend=true tells backend not to close on stale COMPLETED status
            startStreaming(state.currentSessionId, 0, { afterSend: true });
        } else {
            elements.progressText.textContent = 'Создаем новую сессию...';
            elements.confirmPlanBtn.classList.add('hidden');
            
            const res = await window.julesAPI.createSession({
                source_id: state.currentSourceId,
                prompt: prompt,
                starting_branch: state.currentBranch || 'main',
                auto_create_pr: state.config.auto_create_pr,
                confirm_plan: state.config.confirm_plan_before_execution
            });
            
            state.currentSessionId = res.session_id;
            if (typeof loadSessions === 'function') await loadSessions();
            startStreaming(res.session_id);
        }
    } catch (e) {
        addMessage('jules', 'Ошибка: ' + e.message);
        elements.progress.classList.add('hidden');
    }
}

// ─── SSE-based streaming (replaces old polling) ───────────────────────
function startStreaming(sessionId, _retryCount = 0, options = {}) {
    stopStreaming();

    elements.progress.classList.remove('hidden');
    elements.progressText.textContent = _retryCount > 0 
        ? `Переподключение к Jules (${_retryCount})...` 
        : 'Подключение к Jules...';

    state.closeStream = window.julesAPI.streamSession(
        sessionId,

        // onEvent — called whenever status or activities change
        (data) => {
            updateProgressUI(data.status, data.status_label);
            updateSendButtonState();

            // Handle live activities (add as chat messages)
            if (data.activities && data.activities.length > 0) {
                data.activities.forEach(act => {
                    const actId = act.name || JSON.stringify(act);
                    if (!state.displayedActivityIds.has(actId)) {
                        let msg = act.message || 
                                  act.text || 
                                  (act.agentMessaged && act.agentMessaged.agentMessage) ||
                                  (act.userMessaged && act.userMessaged.userMessage) ||
                                  (act.sessionCompleted && act.sessionCompleted.message) ||
                                  (act.progressUpdated && (act.progressUpdated.message || act.progressUpdated.description)) ||
                                  act.description;

                        const role = act.originator === 'user' ? 'user' : 'jules';
                        
                        if (msg) {
                            addMessage(role, msg);
                            state.displayedActivityIds.add(actId);
                        } else if (act.planGenerated && act.planGenerated.plan) {
                            addMessage(role, null, act.planGenerated.plan);
                            state.displayedActivityIds.add(actId);
                        }
                    }
                });
            }

            // Jules awaiting plan confirmation
            if (data.status === 'waitingForUserInput') {
                elements.confirmPlanBtn.classList.remove('hidden');
            }
        },

        // onDone — terminal status reached
        async (data) => {
            state.currentSessionStatus = data.status;
            elements.progress.classList.add('hidden');

            // Fetch final session for export + artifacts
            try {
                const session = await window.julesAPI.getSession(sessionId);
                onSessionComplete(session);
            } catch (e) {
                console.error('Error loading final session:', e);
            }
        },

        // onError — retry up to 5 times
        (err) => {
            console.error('SSE error:', err, `(retry ${_retryCount})`);
            
            if (_retryCount < 5 && state.currentSessionId === sessionId) {
                // Retry after 3 seconds
                setTimeout(() => {
                    if (state.currentSessionId === sessionId) {
                        startStreaming(sessionId, _retryCount + 1, options);
                    }
                }, 3000);
            } else {
                elements.progress.classList.add('hidden');
                addMessage('jules', '⚠️ Потеряно соединение. Нажмите на сессию в списке для обновления.');
            }
        },
        options  // Pass options (afterSend) to preload
    );
}

function stopStreaming() {
    if (state.closeStream) {
        state.closeStream();
        state.closeStream = null;
    }
}

// Update the progress bar with status and live activity log
function updateProgressUI(status, label) {
    state.currentSessionStatus = status;
    elements.progressText.textContent = label || status;
    elements.progress.classList.remove('hidden');

    const spinner = elements.progress.querySelector('.spinner');
    if (!spinner) return;

    // Reset spinner variant classes
    spinner.className = 'spinner';

    if (status === 'agentPlanning')      spinner.classList.add('spinner--thinking');
    if (status === 'agentWorking')       spinner.classList.add('spinner--working');
    if (status === 'sessionCompleted')   { spinner.classList.add('spinner--done'); spinner.classList.add('hidden'); }
    if (status === 'sessionFailed')      spinner.classList.add('hidden');

    // Confirm button for plan approval
    if (status === 'waitingForUserInput') {
        elements.confirmPlanBtn.classList.remove('hidden');
    } else {
        elements.confirmPlanBtn.classList.add('hidden');
    }
}



function updateStatusUI(session) {
    const status = session.status;
    state.currentSessionStatus = status;
    
    let text = 'Jules работает...';
    
    // Try to get granular progress from the latest progressUpdated activity
    if (session.activities && session.activities.length > 0) {
        // Look for the latest progressUpdated activity or any activity with a title/description
        const progressActs = session.activities.filter(a => a.progressUpdated || a.title || a.description);
        if (progressActs.length > 0) {
            const lastProgress = progressActs[progressActs.length - 1];
            if (lastProgress.progressUpdated) {
                text = lastProgress.progressUpdated.title || lastProgress.progressUpdated.description || text;
            } else if (lastProgress.title || lastProgress.description) {
                text = lastProgress.title || lastProgress.description;
            }
        }
    } else {
        // Fallback to general status if no activities yet
        if (status === 'agentPlanning') text = 'Jules составляет план...';
        if (status === 'agentWorking') text = 'Jules выполняет изменения...';
    }
    
    if (status === 'sessionCompleted') text = 'Задача успешно завершена.';
    if (status === 'sessionFailed') text = 'Произошла ошибка.';
    
    // Check if waiting for user
    const isWaiting = status === 'waitingForUserInput' || 
                      status === 'AGENT_WAITING_FOR_USER_INPUT' || 
                      status === 'AWAITING_PLAN_APPROVAL' ||
                      status === 'AWAITING_USER_FEEDBACK';

    if (isWaiting) {
        text = 'Jules ждет подтверждения плана.';
        elements.confirmPlanBtn.classList.remove('hidden');
        elements.progress.classList.remove('hidden');
        const spinner = elements.progress.querySelector('.spinner');
        if (spinner) spinner.classList.remove('hidden');
    } else if (['sessionCompleted', 'sessionFailed'].includes(status)) {
        elements.confirmPlanBtn.classList.add('hidden');
        elements.progress.classList.remove('hidden');
        const spinner = elements.progress.querySelector('.spinner');
        if (spinner) spinner.classList.add('hidden');
    } else {
        elements.confirmPlanBtn.classList.add('hidden');
        elements.progress.classList.remove('hidden');
        const spinner = elements.progress.querySelector('.spinner');
        if (spinner) spinner.classList.remove('hidden');
    }
    
    elements.progressText.textContent = text;
}

async function onSessionComplete(session) {
    elements.progress.classList.add('hidden');
    
    // Load artifacts using state.currentSessionId which is the raw Jules session ID
    const sessionId = state.currentSessionId;
    const artifacts = await window.julesAPI.getArtifacts(sessionId);
    console.log('onSessionComplete artifacts:', artifacts);
    if (artifacts && artifacts.length > 0) {
        renderArtifacts(artifacts);
    } else {
        addMessage('jules', '✅ Задача завершена. Файлы сохранены в папку output/sessions.');
    }
    
    addMessage('jules', '💡 Вы можете отправить дополнительное сообщение ниже, чтобы продолжить работу в этой же ветке (sendMessage).');
    
    await loadSessions();
}

function addMessage(role, text, plan = null) {
    // Remove empty state
    const empty = elements.messages.querySelector('.empty-state');
    if (empty) empty.remove();
    
    const msgDiv = document.createElement('div');
    msgDiv.className = `message ${role}`;
    
    if (plan) {
        msgDiv.appendChild(renderPlanAccordion(plan));
    } else if (text) {
        // Sanitized Markdown
        const rawHtml = marked.parse(text);
        msgDiv.innerHTML = DOMPurify.sanitize(rawHtml);
    }
    
    elements.messages.appendChild(msgDiv);
    elements.messages.scrollTop = elements.messages.scrollHeight;
}

function renderPlanAccordion(plan) {
    const container = document.createElement('div');
    container.className = 'plan-container';
    
    const header = document.createElement('div');
    header.className = 'plan-header';
    header.innerHTML = `
        <div class="header-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
        </div>
        <span>План действий Jules</span>
    `;
    container.appendChild(header);
    
    const steps = plan.steps || [];
    steps.forEach((step, index) => {
        const details = document.createElement('details');
        details.className = 'plan-step';
        if (index === 0) details.open = true; // Open first step by default
        
        details.innerHTML = `
            <summary class="step-summary">
                <div class="step-title-wrap">
                    <div class="step-number">${index + 1}</div>
                    <div class="step-title">${step.title}</div>
                </div>
                <div class="step-icon">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                </div>
            </summary>
            <div class="step-content">
                ${marked.parse(step.description || '')}
            </div>
        `;
        container.appendChild(details);
    });
    
    return container;
}

function renderArtifacts(artifacts) {
    const container = document.createElement('div');
    container.className = 'artifacts';
    
    artifacts.forEach(art => {
        const card = document.createElement('div');
        card.className = 'artifact-card';
        
        const info = document.createElement('div');
        info.className = 'info';
        info.innerHTML = `<div class="name">${art.filename}</div>`;
        
        const btn = document.createElement('button');
        btn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>`;
        
        btn.onclick = () => window.downloadFile(art.filepath);
        
        card.appendChild(info);
        card.appendChild(btn);
        container.appendChild(card);
    });
    
    elements.messages.appendChild(container);
    elements.messages.scrollTop = elements.messages.scrollHeight;
}

window.downloadFile = async (path) => {
    try {
        const blob = await window.julesAPI.downloadArtifact(path);
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = path.split('\\').pop().split('/').pop();
        document.body.appendChild(a);
        a.click();
        a.remove();
    } catch (e) {
        alert('Ошибка при скачивании файла: ' + e.message);
    }
};

async function saveSettings() {
    const newConfig = {
        jules_api_key: elements.apiKeyInput.value,
        output_dir: elements.outputDirInput.value,
        theme: elements.themeSelector.value,
        confirm_plan_before_execution: elements.confirmPlanToggle.checked,
        auto_create_pr: elements.autoPrToggle.checked
    };
    
    try {
        await window.julesAPI.saveConfig(newConfig);
        state.config = newConfig;
        document.documentElement.setAttribute('data-theme', newConfig.theme);
        elements.settingsPanel.classList.add('hidden');
        await loadSources();
    } catch (e) {
        alert('Ошибка сохранения настроек: ' + e.message);
    }
}

// Start app
init();
