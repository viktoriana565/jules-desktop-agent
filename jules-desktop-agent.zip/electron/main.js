const { app, BrowserWindow, Tray, Menu, nativeImage, shell, ipcMain, dialog } = require('electron')
const { spawn } = require('child_process')
const path = require('path')
const http = require('http')

let mainWindow
let tray
let pythonProcess

function killPortProcess(port) {
    return new Promise((resolve) => {
        // Find and kill any process using the given port (Windows)
        const { exec } = require('child_process')
        exec(`netstat -ano | findstr :${port}`, (err, stdout) => {
            if (err || !stdout) return resolve()
            const lines = stdout.trim().split('\n')
            const pids = new Set()
            lines.forEach(line => {
                const parts = line.trim().split(/\s+/)
                const pid = parts[parts.length - 1]
                if (pid && pid !== '0') pids.add(pid)
            })
            if (pids.size === 0) return resolve()
            let remaining = pids.size
            pids.forEach(pid => {
                exec(`taskkill /PID ${pid} /F`, () => {
                    remaining--
                    if (remaining === 0) resolve()
                })
            })
        })
    })
}

async function startBackend() {
    await killPortProcess(8765)
    const pythonExe = app.isPackaged ? path.join(process.resourcesPath, 'backend.exe') : 'python'
    const scriptPath = path.join(__dirname, '..', 'backend', 'main.py')
    
    const backendDir = path.join(__dirname, '..', 'backend')
    pythonProcess = spawn(pythonExe, [scriptPath], { cwd: backendDir })

    pythonProcess.stdout.on('data', (data) => {
        console.log(`Backend: ${data}`)
    })

    pythonProcess.stderr.on('data', (data) => {
        console.error(`Backend Error: ${data}`)
    })

    pythonProcess.on('error', (err) => {
        console.error('Failed to spawn python process:', err)
    })
}

function createTray() {
    const iconPath = path.join(__dirname, '..', 'assets', 'tray-icon.png')
    const icon = nativeImage.createFromPath(iconPath)
    tray = new Tray(icon)
    
    const contextMenu = Menu.buildFromTemplate([
        { label: 'Открыть Jules Agent', click: () => mainWindow.show() },
        { label: 'Новая задача', click: () => {
            mainWindow.show()
            mainWindow.webContents.send('focus-input')
        }},
        { type: 'separator' },
        { label: 'Выход', click: () => app.quit() }
    ])

    tray.setToolTip('Jules Desktop Agent')
    tray.setContextMenu(contextMenu)
    
    tray.on('click', () => {
        mainWindow.isVisible() ? mainWindow.hide() : mainWindow.show()
    })
}

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1000,
        height: 800,
        minWidth: 600,
        minHeight: 500,
        frame: false,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false
        },
        show: true
    })

    mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'))

    mainWindow.on('close', (event) => {
        if (!app.isQuitting) {
            event.preventDefault()
            mainWindow.hide()
        }
        return false
    })
}

app.whenReady().then(() => {
    startBackend()
    createWindow()
    createTray()
})

app.on('before-quit', () => {
    app.isQuitting = true
    if (pythonProcess) pythonProcess.kill()
})

ipcMain.handle('window-minimize', () => {
    mainWindow.minimize()
})

ipcMain.handle('window-hide', () => {
    mainWindow.hide()
})

ipcMain.handle('open-folder', (event, folderPath) => {
    shell.openPath(folderPath)
})

ipcMain.handle('select-folder', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
        properties: ['openDirectory']
    })
    if (!result.canceled) {
        return result.filePaths[0]
    }
    return null
})

// Check backend health
ipcMain.handle('check-backend', async () => {
    return new Promise((resolve) => {
        http.get('http://localhost:8765/health', (res) => {
            resolve(res.statusCode === 200)
        }).on('error', () => {
            resolve(false)
        })
    })
})
