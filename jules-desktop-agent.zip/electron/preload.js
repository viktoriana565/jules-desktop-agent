const { contextBridge, ipcRenderer, shell } = require('electron')

const checkResponse = async (r) => {
  if (!r.ok) {
    const err = await r.json().catch(() => ({}));
    throw new Error(err.detail || r.statusText);
  }
  return r.json();
};

contextBridge.exposeInMainWorld('julesAPI', {
  // Calls to Python backend
  getConfig: () => fetch('http://localhost:8765/config').then(checkResponse),
  saveConfig: (config) => fetch('http://localhost:8765/config', {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(config)
  }).then(checkResponse),

  getSources: () => fetch('http://localhost:8765/sources').then(checkResponse),
  
  createSession: (data) => fetch('http://localhost:8765/sessions', {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(data)
  }).then(checkResponse),

  getSession: (id) => fetch(`http://localhost:8765/sessions/${id}`).then(checkResponse),
  getSessions: () => fetch('http://localhost:8765/sessions').then(checkResponse),
  confirmPlan: (id) => fetch(`http://localhost:8765/sessions/${id}/confirm`, {method:'POST'}).then(checkResponse),
  sendMessage: (id, prompt) => fetch(`http://localhost:8765/sessions/${id}/message`, {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({prompt})
  }).then(checkResponse),
  getArtifacts: (id) => fetch(`http://localhost:8765/sessions/${id}/artifacts`).then(checkResponse),

  // SSE — real-time session status stream
  // options: { afterSend: boolean } — if true, tells backend to wait for new activities
  streamSession: (sessionId, onEvent, onDone, onError, options = {}) => {
    const params = options.afterSend ? '?after_send=true' : '';
    const es = new EventSource(
      `http://localhost:8765/sessions/${sessionId}/stream${params}`
    );
    es.onmessage = (e) => {
      try {
        const data = JSON.parse(e.data);
        if (data.done) {
          es.close();
          onDone(data);
        } else if (data.error) {
          es.close();
          onError(data.error);
        } else {
          onEvent(data);
        }
      } catch (err) {
        console.error('SSE parse error', err);
      }
    };
    es.onerror = () => {
      es.close();
      onError('SSE connection lost');
    };
    // Return a handle to close manually
    return () => es.close();
  },
  
  // File actions
  downloadArtifact: (path) => fetch(`http://localhost:8765/artifacts/download?path=${encodeURIComponent(path)}`).then(r => r.blob()),

  // System
  openFolder: (path) => ipcRenderer.invoke('open-folder', path),
  selectFolder: () => ipcRenderer.invoke('select-folder'),
  minimizeWindow: () => ipcRenderer.invoke('window-minimize'),
  closeWindow: () => ipcRenderer.invoke('window-hide'),
  checkBackend: () => ipcRenderer.invoke('check-backend'),
  onFocusInput: (cb) => ipcRenderer.on('focus-input', cb)
})
