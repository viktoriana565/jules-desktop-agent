# Jules Desktop Agent

Минималистичное Windows desktop-приложение для работы с Google Jules API.  
Отправляет задачи AI-агенту, отслеживает прогресс в реальном времени, сохраняет результаты в `.md` и `.patch` файлы.

---

## Требования

| Компонент | Версия |
|-----------|--------|
| Node.js   | 20+    |
| Python    | 3.11+  |
| npm       | 9+     |
| Jules API Key | [Google AI Studio](https://aistudio.google.com/) |

---

## Быстрый старт

Все команды выполняются из **корня проекта** (`jules-desktop-agent/`).

### 1. Установить зависимости

```bash
# Node-зависимости (Electron)
npm install

# Python-зависимости (FastAPI backend)
pip install -r backend/requirements.txt
```

### 2. Запустить приложение

```bash
npm start
```

Эта команда запускает **Electron**, который автоматически:
- Поднимает Python-бэкенд на `localhost:8765`
- Открывает окно приложения
- Создаёт иконку в системном трее

> **Запускать бэкенд вручную не нужно** — Electron делает это сам через `child_process.spawn`.

### 3. Настроить API-ключ

При первом запуске откройте **Настройки** (⚙️ в заголовке окна) и введите Jules API Key.  
После нажатия «Сохранить» файл `backend/config.json` создастся автоматически.

---

## Архитектура

```
┌──────────────────────────────────────┐
│  Electron (main.js)                  │
│  ├─ spawn python backend/main.py     │
│  ├─ createWindow → renderer/         │
│  └─ createTray → системный трей      │
└──────────┬───────────────────────────┘
           │ fetch http://localhost:8765
┌──────────▼───────────────────────────┐
│  FastAPI Backend (Python)            │
│  ├─ Jules API клиент (httpx)         │
│  ├─ SQLite хранилище сессий          │
│  ├─ SSE стриминг статуса             │
│  └─ Экспорт .md / .patch файлов     │
└──────────┬───────────────────────────┘
           │ HTTPS
┌──────────▼───────────────────────────┐
│  Google Jules API                    │
│  jules.googleapis.com/v1alpha        │
└──────────────────────────────────────┘
```

---

## Структура проекта

```
jules-desktop-agent/
├── electron/
│   ├── main.js              # Entry point — запуск backend, окно, трей
│   ├── preload.js           # IPC bridge (contextBridge → fetch к backend)
│   └── renderer/
│       ├── index.html       # UI разметка
│       ├── style.css        # Стили (CSS custom properties, dark/light)
│       └── app.js           # Логика интерфейса
├── backend/
│   ├── main.py              # FastAPI сервер на порту 8765
│   ├── jules_client.py      # HTTP-клиент Jules API
│   ├── session_store.py     # SQLite через SQLAlchemy (async)
│   ├── file_exporter.py     # Сохранение MD и patch файлов
│   ├── models.py            # Pydantic v2 модели
│   ├── requirements.txt     # Python-зависимости
│   └── config.json          # ⛔ Локальный конфиг (не коммитить!)
├── assets/
│   ├── icon.png             # Иконка приложения
│   └── tray-icon.png        # Иконка в системном трее
├── output/                  # Результаты сессий (создаётся автоматически)
├── package.json
├── .gitignore
└── README.md
```

---

## Конфигурация

Файл `backend/config.json` создаётся через UI при сохранении настроек.  
Формат:

```json
{
    "jules_api_key": "ваш-ключ",
    "output_dir": "C:\\путь\\к\\папке\\sessions",
    "polling_interval_ms": 5000,
    "theme": "dark",
    "confirm_plan_before_execution": true,
    "auto_create_pr": false
}
```

> ⚠️ `config.json` содержит API-ключ и **не должен попадать в git** (добавлен в `.gitignore`).

---

## Запуск только бэкенда (для отладки)

Если нужно запустить Python-сервер отдельно без Electron:

```bash
cd backend
python main.py
```

Сервер поднимется на `http://localhost:8765`. Полезно для тестирования API-эндпоинтов через curl / Postman.

---

## Сборка (Windows installer)

```bash
npm run build
```

Создаёт NSIS-инсталлятор в папке `dist/`. Для продакшена бэкенд упаковывается через PyInstaller в `backend.exe`.
