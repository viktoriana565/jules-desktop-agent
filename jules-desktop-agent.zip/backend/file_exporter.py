import os
import re
from datetime import datetime
from pathlib import Path

def slugify(text: str) -> str:
    text = str(text).lower()
    # Replace non-word chars (support unicode)
    text = re.sub(r'[^\w\s-]', '', text, flags=re.UNICODE)
    return re.sub(r'[-\s]+', '-', text).strip('-') or "session"

class FileExporter:
    def __init__(self, output_dir: str):
        p = Path(os.path.abspath(output_dir))
        # Avoid sessions/sessions nesting if output_dir already ends with 'sessions'
        if p.name.lower() != "sessions":
            p = p / "sessions"
        self.output_dir = p
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def create_session_dir(self, session_id: str, prompt: str) -> Path:
        """
        Создать уникальную папку для сессии на основе её ID.
        Возвращает абсолютный путь.
        """
        clean_id = session_id.split("/")[-1]
        slug = slugify(prompt[:30])
        dir_name = f"{slug}_{clean_id}"
        session_dir = self.output_dir / dir_name
        session_dir.mkdir(parents=True, exist_ok=True)
        return session_dir.resolve()

    def save_md_response(self, session_dir: Path, session_data: dict, prompt: str) -> Path:
        """
        Сохранить ответ агента в response.md с полной историей диалога.
        """
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        status_label = "✅ Выполнено" if session_data.get("status") == "sessionCompleted" else "❌ Ошибка"
        
        # Build chat transcript
        transcript = []
        activities = session_data.get("activities", [])
        
        for act in activities:
            # Detect role
            role = "Agent"
            if act.get("originator") == "user" or act.get("origin") == "user" or "userMessaged" in act:
                role = "User"
            
            # Robust message extraction
            msg = act.get("message") or \
                  act.get("text") or \
                  (act.get("agentMessaged", {})).get("agentMessage") or \
                  (act.get("userMessaged", {})).get("userMessage") or \
                  (act.get("sessionCompleted", {})).get("message") or \
                  (act.get("progressUpdated", {})).get("message") or \
                  (act.get("progressUpdated", {})).get("description") or \
                  act.get("description")
            
            if msg:
                transcript.append(f"### {role}\n\n{msg}")
            
            # Check for plan
            if "planGenerated" in act:
                plan = act["planGenerated"].get("plan", {})
                steps = plan.get("steps", [])
                if steps:
                    plan_text = "#### План действий:\n\n"
                    for i, step in enumerate(steps, 1):
                        plan_text += f"{i}. **{step.get('title')}**: {step.get('description')}\n"
                    transcript.append(plan_text)

        dialog_content = "\n\n".join(transcript) if transcript else "No detailed history available."
        
        pr_url = session_data.get("pr_url") or "Not created"

        content = f"""# Jules Session — {now}

**Задача:** {prompt}
**Статус:** {status_label}

---

## История диалога

{dialog_content}

## Pull Request

{pr_url}

---
*Сгенерировано Jules Desktop Agent 0.1.0*
"""
        filepath = session_dir / "response.md"
        filepath.write_text(content, encoding='utf-8')
        return filepath

    def save_extra_artifact(self, session_dir: Path, filename: str, content: str) -> Path:
        """Сохранить произвольный файл артефакта"""
        filepath = session_dir / filename
        if isinstance(content, str):
            filepath.write_text(content, encoding='utf-8')
        else:
            filepath.write_bytes(content)
        return filepath

    def save_patch(self, session_dir: Path, git_patch: str) -> Path:
        """Сохранить git diff в changes.patch"""
        filepath = session_dir / "changes.patch"
        filepath.write_text(git_patch, encoding='utf-8')
        return filepath

    def extract_files_from_patch(self, git_patch: str) -> list[dict]:
        """
        Парсит git patch и извлекает содержимое новых файлов.
        Возвращает список [{filename, content}]
        """
        files = []
        if not git_patch: return files
        
        # Simple parser for unidiff
        chunks = re.split(r'^diff --git ', git_patch, flags=re.MULTILINE)
        for chunk in chunks:
            if not chunk: continue
            
            # Find filename
            match = re.search(r'^\+\+\+ b/(.+)$', chunk, flags=re.MULTILINE)
            if not match: continue
            filename = match.group(1).strip()
            
            # Extract content (lines starting with + but not +++)
            lines = chunk.split('\n')
            content_lines = []
            for line in lines:
                if line.startswith('+') and not line.startswith('+++'):
                    content_lines.append(line[1:]) # removal of the leading '+'
            
            if content_lines:
                files.append({
                    "filename": filename,
                    "content": '\n'.join(content_lines)
                })
        return files

    def get_session_artifacts(self, session_dir: Path) -> list[dict]:
        """Вернуть список файлов в папке сессии для отображения в UI"""
        artifacts = []
        if not session_dir.exists():
            return artifacts
            
        for file in session_dir.iterdir():
            if file.is_file():
                artifacts.append({
                    "name": file.name,
                    "path": str(file.absolute()),
                    "type": "git_patch" if file.suffix == ".patch" else "md_response"
                })
        return artifacts
