import os
import re
import json
import asyncio
import traceback
from pathlib import Path
from typing import List, Optional
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel

from models import Config, CreateSessionRequest, SessionResponse, ActivityResponse, SourceInfo, SendMessageRequest
from jules_client import JulesClient
from session_store import SessionStore
from file_exporter import FileExporter

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    global exporter, jules
    print(f">>> Backend CWD: {os.getcwd()}")
    await db.init_db()
    config = load_config()
    print(f">>> Config output_dir: {config.output_dir}")
    if config.jules_api_key:
        jules = JulesClient(config.jules_api_key)
    exporter = FileExporter(config.output_dir)
    print(f">>> FileExporter output_dir: {exporter.output_dir}")
    yield
    # Shutdown

app = FastAPI(title="Jules Agent Backend", lifespan=lifespan)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

CONFIG_FILE = "config.json"
db = SessionStore()
exporter = None
jules = None

def load_config() -> Config:
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return Config(**data)
    return Config(jules_api_key="", output_dir="output")

def save_config_to_file(config: Config):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config.dict(), f, indent=4, ensure_ascii=False)



@app.get("/health")
async def health():
    return {"status": "ok"}

@app.get("/config")
async def get_config():
    return load_config()

@app.post("/config")
async def save_config(config: Config):
    global jules, exporter
    save_config_to_file(config)
    jules = JulesClient(config.jules_api_key)
    exporter = FileExporter(config.output_dir)
    return {"status": "saved"}

@app.get("/sources")
async def get_sources():
    if not jules:
        raise HTTPException(status_code=400, detail="Jules API key not configured")
    try:
        sources = await jules.list_sources()
        for s in sources:
            await db.save_source(s.id, s.name, s.github_url)
        return sources
    except Exception as e:
        print(f"Error fetching sources: {e}")
        return await db.get_sources()

import httpx

# ─── Human-readable status labels ────────────────────────────────────
STATUS_LABELS = {
    "QUEUED":                  "Jules в очереди...",
    "PLANNING":                "Jules составляет план...",
    "AWAITING_PLAN_APPROVAL":  "Ожидает подтверждения плана",
    "IN_PROGRESS":             "Jules работает...",
    "AWAITING_USER_FEEDBACK":  "Jules задаёт вопрос",
    "PAUSED":                  "Сессия на паузе",
    "COMPLETED":               "Готово ✅",
    "FAILED":                  "Ошибка ❌",
    # Legacy / normalised keys
    "sessionCreated":          "Сессия создана",
    "agentPlanning":           "Jules составляет план...",
    "agentWorking":            "Jules выполняет изменения...",
    "waitingForUserInput":     "Jules ждёт подтверждения",
    "sessionCompleted":        "Готово ✅",
    "sessionFailed":           "Ошибка ❌",
}

def _extract_latest_text(activities: list) -> str:
    """Pull latest meaningful text from activities list."""
    for act in reversed(activities):
        if not isinstance(act, dict):
            continue
        # progressUpdated
        pu = act.get("progressUpdated")
        if isinstance(pu, dict):
            t = pu.get("title") or pu.get("description") or pu.get("message")
            if t:
                return t
        # agentMessaged
        am = act.get("agentMessaged")
        if isinstance(am, dict):
            t = am.get("agentMessage")
            if t:
                return t
        # planGenerated
        pg = act.get("planGenerated")
        if isinstance(pg, dict) and pg.get("plan"):
            return "План сгенерирован"
    return ""

def _normalise_status(raw: str) -> str:
    """Map raw Jules API status to the normalised key used in the frontend."""
    if not raw:
        return "unknown"
    up = raw.upper()
    mapping = {
        "COMPLETED": "sessionCompleted",
        "SESSION_COMPLETED": "sessionCompleted",
        "FAILED": "sessionFailed",
        "SESSION_FAILED": "sessionFailed",
        "AWAITING_PLAN_APPROVAL": "waitingForUserInput",
        "PLAN_APPROVAL": "waitingForUserInput",
        "AWAITING_USER_FEEDBACK": "waitingForUserInput",
        "QUEUED": "agentPlanning",
        "PLANNING": "agentPlanning",
        "IN_PROGRESS": "agentWorking",
    }
    return mapping.get(up, raw)


@app.get("/sessions/{session_id}/stream")
async def stream_session(session_id: str, after_send: bool = False):
    """SSE stream — pushes status / activity changes to the client in real-time.
    
    If after_send=true, the stream won't close on a terminal status (COMPLETED/FAILED)
    until new activities appear beyond the initial snapshot. This handles the case
    where a user sends a followup message to an already-completed session.
    """
    if not jules:
        raise HTTPException(status_code=400, detail="Jules API key not configured")

    async def event_generator():
        # Ask browser to reconnect after 3 s if the connection drops
        yield "retry: 3000\n\n"

        prev_status = None
        prev_activity_count = 0
        prev_latest_text = ""
        consecutive_errors = 0
        
        # When after_send=True, we record the initial activity count
        # and don't close until we see new activities
        initial_activity_count = None
        saw_new_activities = False

        while True:
            try:
                session_data = await jules.get_session(session_id)
                activities_data = await jules.get_activities(session_id)
                consecutive_errors = 0  # Reset on success

                # ── Resolve activities list ──
                acts = []
                if isinstance(activities_data, dict):
                    acts = activities_data.get("activities", [])
                elif isinstance(activities_data, list):
                    acts = activities_data

                # Record initial activity count on first successful poll
                if initial_activity_count is None:
                    initial_activity_count = len(acts)
                    if after_send:
                        print(f"SSE stream: after_send mode, initial activities={initial_activity_count}")
                
                # Check if new activities arrived since stream start
                if len(acts) > initial_activity_count:
                    saw_new_activities = True

                # ── Resolve status (same logic as GET /sessions/{id}) ──
                raw_api_status = session_data.get("status") or session_data.get("state") or session_data.get("currentStatus")
                status = _normalise_status(raw_api_status)

                # Smart fallback from activities
                if acts:
                    # In after_send mode, only scan NEW activities for terminal markers
                    # (old sessionCompleted/sessionFailed must be ignored)
                    check_acts = acts[initial_activity_count:] if after_send else acts
                    
                    has_completion = any("sessionCompleted" in a for a in check_acts)
                    has_failure    = any("sessionFailed" in a for a in check_acts)
                    has_plan       = any("planGenerated" in a for a in acts)  # check all for plans
                    has_approval   = any("planApproved" in a for a in acts)   # check all for approvals
                    
                    if has_completion:
                        status = "sessionCompleted"
                    elif has_failure:
                        status = "sessionFailed"
                    elif has_plan and not has_approval:
                        status = "waitingForUserInput"
                    elif status in ("unknown",):
                        status = "agentWorking"

                    # If after_send and no new activities yet, override any terminal status
                    # (the API might still report COMPLETED from the previous run)
                    if after_send and not saw_new_activities and status in ("sessionCompleted", "sessionFailed"):
                        status = "agentWorking"  # Jules is processing the new message

                latest_text = _extract_latest_text(acts)

                # ── Only push if something changed ──
                changed = (
                    status != prev_status
                    or len(acts) != prev_activity_count
                    or latest_text != prev_latest_text
                )

                if changed:
                    prev_status = status
                    prev_activity_count = len(acts)
                    prev_latest_text = latest_text

                    event = {
                        "status": status,
                        "status_label": STATUS_LABELS.get(status, status),
                        "latest_message": latest_text,
                        "activity_count": len(acts),
                        "activities": acts,
                    }
                    if after_send:
                        print(f"SSE [{session_id[:8]}]: status={status}, acts={len(acts)}, new={saw_new_activities}, initial={initial_activity_count}")
                    yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"

                # ── Terminal states → close stream ──
                if status in ("sessionCompleted", "sessionFailed"):
                    yield f"data: {json.dumps({'status': status, 'done': True})}\n\n"
                    break

                await asyncio.sleep(2)

            except asyncio.CancelledError:
                break
            except Exception as e:
                consecutive_errors += 1
                print(f"SSE stream error ({consecutive_errors}/5) for {session_id}: {e}")
                if consecutive_errors >= 5:
                    yield f"data: {json.dumps({'error': str(e)})}\n\n"
                    break
                # Transient error — wait and retry
                await asyncio.sleep(3)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "Connection": "keep-alive",
        },
    )

@app.post("/sessions")
async def create_session(req: CreateSessionRequest):
    if not jules:
        raise HTTPException(status_code=400, detail="Jules API key not configured")
    
    try:
        res = await jules.create_session(
            req.source_id, 
            req.prompt,
            starting_branch=req.starting_branch,
            auto_create_pr=req.auto_create_pr,
            confirm_plan=req.confirm_plan
        )
        session_id = res["name"].split("/")[-1]
        
        await db.save_session(
            session_id=session_id,
            source_id=req.source_id,
            prompt=req.prompt,
            status="sessionCreated"
        )
        
        # Save last used repo/branch to config
        config = load_config()
        config.last_source_id = req.source_id
        config.last_branch = req.starting_branch
        save_config_to_file(config)
        
        return {"session_id": session_id, "status": "sessionCreated"}
    except httpx.HTTPStatusError as e:
        error_detail = f"{e}: {e.response.text}"
        print("HTTP Error:", error_detail)
        raise HTTPException(status_code=502, detail=error_detail)
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))

@app.post("/sessions/{session_id}/message")
async def send_message(session_id: str, body: SendMessageRequest):
    """
    Продолжить разговор в существующей сессии.
    Jules продолжает работу в той же ветке репозитория.
    """
    if not jules:
        raise HTTPException(status_code=400, detail="Jules API key not configured")
    try:
        result = await jules.send_followup(session_id, body.prompt)
        await db.add_user_message(session_id, body.prompt)
        return result
    except httpx.HTTPStatusError as e:
        error_detail = f"Jules API Error: {e.response.text}"
        print(f"sendMessage error: {error_detail}")
        raise HTTPException(status_code=502, detail=error_detail)
    except Exception as e:
        print(f"sendMessage error: {e}")
        raise HTTPException(status_code=502, detail=str(e))

@app.get("/sessions")
async def get_sessions_history():
    return await db.get_sessions_history()

@app.get("/debug/session/{session_id}")
async def debug_session(session_id: str):
    """Developer endpoint: show raw Jules API data for a session"""
    if not jules:
        raise HTTPException(status_code=400, detail="Jules API key not configured")
    session_data = await jules.get_session(session_id)
    activities_data = await jules.get_activities(session_id)
    
    # Print all activity keys for debugging
    acts = []
    if isinstance(activities_data, dict):
        acts = activities_data.get("activities", [])
    elif isinstance(activities_data, list):
        acts = activities_data
    
    activity_summary = []
    for i, act in enumerate(acts):
        keys = list(act.keys())
        typed_keys = [k for k in keys if k not in ("name", "createTime", "originator")]
        entry = {"index": i, "keys": keys, "typed_keys": typed_keys}
        for tk in typed_keys:
            if isinstance(act.get(tk), dict):
                entry[f"{tk}_keys"] = list(act[tk].keys())
        activity_summary.append(entry)
    
    return {
        "session_keys": list(session_data.keys()) if isinstance(session_data, dict) else "not a dict",
        "activities_type": type(activities_data).__name__,
        "activities_keys": list(activities_data.keys()) if isinstance(activities_data, dict) else "list",
        "activity_count": len(acts),
        "activity_summary": activity_summary,
        "session_data": session_data,
    }

@app.get("/sessions/{session_id}")
async def get_session_status(session_id: str):
    if not jules:
        raise HTTPException(status_code=400, detail="Jules API key not configured")
    
    try:
        # Fetch both session data (for status) and activities
        session_data = await jules.get_session(session_id)
        activities_data = await jules.get_activities(session_id)
        
        # Combine data robustly
        data = {"activities": []}
        if isinstance(activities_data, list):
            data["activities"] = activities_data
        elif isinstance(activities_data, dict):
            data.update(activities_data)
            if "activities" not in data:
                data["activities"] = []
        
        # Merge session metadata into data object (don't overwrite activities)
        if isinstance(session_data, dict):
            for k, v in session_data.items():
                if k not in data or k == "status": # Prioritize session_data for status
                    data[k] = v
        
        # 1. Extract status from multiple fields
        status = session_data.get("status") or session_data.get("state") or session_data.get("currentStatus")
        
        # Normalize status
        if status:
            status_up = status.upper()
            if status_up == "COMPLETED" or status_up == "SESSION_COMPLETED": status = "sessionCompleted"
            elif status_up == "FAILED" or status_up == "SESSION_FAILED": status = "sessionFailed"
            elif status_up == "AWAITING_PLAN_APPROVAL" or status_up == "PLAN_APPROVAL": status = "waitingForUserInput"
            elif status_up == "AWAITING_USER_FEEDBACK": status = "waitingForUserInput"
        
        # 2. Smart status fallback from activities (more robust scanning)
        if data.get("activities"):
            acts = data["activities"]
            has_completion = any("sessionCompleted" in a for a in acts)
            has_failure = any("sessionFailed" in a for a in acts)
            has_plan = any("planGenerated" in a for a in acts)
            has_approval = any("planApproved" in a for a in acts)
            
            # Priority 1: explicitly finished activities
            if has_completion: status = "sessionCompleted"
            elif has_failure: status = "sessionFailed"
            # Priority 2: Plan is waiting for approval
            elif has_plan and not has_approval: status = "waitingForUserInput"
            # Priority 3: Last activity is an interaction/message from agent
            elif any(k in acts[-1] for k in ["userInteraction", "agentMessaged", "agentQuestion"]):
                status = "waitingForUserInput"
            
            # Final fallback for transient states
            if not status or status in ("unknown", "PLANNING", "IN_PROGRESS", "QUEUED"):
                if has_plan and not has_approval: status = "waitingForUserInput"
                else: status = "agentWorking"
            
        status = status or "unknown"
        data["status"] = status
        
        # Normalize ID for DB
        clean_id = session_id.split("/")[-1]
        
        # Update DB with the correct (potentially smart-detected) status
        await db.update_session_status(clean_id, status)
        
        # Debugging info
        if not data.get("activities"):
            print(f"DEBUG: No activities key found for {session_id}")
        else:
            print(f"DEBUG: Found {len(data['activities'])} activities for {session_id}. Final Status: {status}")
        
        # Add prompt from DB if missing
        clean_id = session_id.split("/")[-1]
        db_session = await db.get_session(clean_id)
        if db_session:
            data["prompt"] = db_session.prompt
            
        # 3. Export files if completed
        if status == "sessionCompleted":
            try:
                # Always ensure we use the cleaned ID for DB and folder naming
                clean_id = session_id.split("/")[-1]
                
                print(f">>> Processing export for session {clean_id}")
                prompt_text = data.get("prompt") or "Jules Task"
                
                # 3.1. Ensure we have a directory
                existing_artifacts = await db.get_session_artifacts(clean_id)
                session_dir = None
                if existing_artifacts and existing_artifacts[0].filepath:
                    try:
                        p = Path(existing_artifacts[0].filepath)
                        if p.parent.exists():
                            session_dir = p.parent
                    except:
                        pass
                
                if not session_dir:
                    session_dir = exporter.create_session_dir(clean_id, prompt_text)
                
                # 3.2. Save/Update MD Report (always update history)
                md_path = exporter.save_md_response(session_dir, data, prompt_text)
                if not any(a.type == "md_response" for a in existing_artifacts):
                    await db.save_artifact(clean_id, "md_response", md_path.name, md_path.as_posix())
                    print(f">>> Saved new MD response reference: {md_path.name}")
                else:
                    print(f">>> Updated MD response file: {md_path.name}")

                # 3.3. Search for all artifacts in activities (correct structure)
                # Jules API: activity.artifacts = [{ changeSet: { gitPatch: { unidiffPatch: "..." } } }]
                collected_patch = None
                for act in data.get("activities", []):
                    if not isinstance(act, dict): continue
                    arts = act.get("artifacts", [])
                    if not isinstance(arts, list): continue
                    
                    for art in arts:
                        if not isinstance(art, dict): continue
                        
                        # Primary structure: changeSet -> gitPatch -> unidiffPatch
                        change_set = art.get("changeSet", {})
                        if not isinstance(change_set, dict): continue
                        
                        git_patch = change_set.get("gitPatch", {})
                        if not isinstance(git_patch, dict): continue
                        
                        unidiff = git_patch.get("unidiffPatch")
                        if unidiff:
                            collected_patch = unidiff
                            continue
                        
                        # Fallback: direct gitPatch at art level
                        direct_patch = art.get("gitPatch")
                        if isinstance(direct_patch, dict):
                            p = direct_patch.get("unidiffPatch")
                            if p: collected_patch = p
                        elif isinstance(direct_patch, str) and direct_patch:
                            collected_patch = direct_patch
                
                if collected_patch:
                    p_name = "changes.patch"
                    # Save patch file itself if not exists
                    if not any(a.filename == p_name for a in existing_artifacts):
                        pp = exporter.save_patch(session_dir, collected_patch)
                        await db.save_artifact(clean_id, "git_patch", pp.name, pp.as_posix())
                        print(">>> Saved Git patch")
                        # Refresh list
                        existing_artifacts = await db.get_session_artifacts(clean_id)
                    
                    # ALWAYS try to extract individual files if they are missing
                    try:
                        extracted = exporter.extract_files_from_patch(collected_patch)
                        for ef in extracted:
                            ef_name = re.sub(r'[\\/*?:"<>|]', "_", str(ef["filename"]))
                            if not any(a.filename == ef_name for a in existing_artifacts):
                                ep = exporter.save_extra_artifact(session_dir, ef_name, ef["content"])
                                await db.save_artifact(clean_id, "file", ep.name, ep.as_posix())
                                print(f">>> Extracted missing file from patch: {ef_name}")
                                # Refresh list to avoid processing same file twice
                                existing_artifacts = await db.get_session_artifacts(clean_id)
                    except Exception as e:
                        print(f">>> Error extracting from patch: {e}")
                else:
                    print(">>> No git patch found in any activity artifacts")
                
                # 3.4. Extract PR URL from session outputs or url field
                pr_url = "Not created"
                if isinstance(session_data, dict):
                    outputs = session_data.get("outputs") or {}
                    if isinstance(outputs, dict):
                        pr_url = outputs.get("pullRequestUrl")
                    
                    if not pr_url:
                        pr_url = session_data.get("url") or session_data.get("prUrl") or "Not created"
                elif isinstance(session_data, list) and len(session_data) > 0:
                    first = session_data[0]
                    if isinstance(first, dict):
                        pr_url = first.get("url") or first.get("pullRequestUrl") or "Not created"
                
                if pr_url and pr_url != "Not created":
                    print(f">>> PR URL: {pr_url}")

            except Exception as e:
                print(f"Error during export: {e}")
                traceback.print_exc()
        
        return data
    except httpx.HTTPStatusError as e:
        print(f"Jules API Error: {e.response.text}")
        raise HTTPException(status_code=502, detail=f"Jules API Error: {e.response.text}")
    except Exception as e:
        print("Backend Error trace:")
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/sessions/{session_id}/confirm")
async def confirm_plan(session_id: str):
    if not jules:
        raise HTTPException(status_code=400, detail="Jules API key not configured")
    try:
        return await jules.confirm_plan(session_id)
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=502, detail=f"{e}: {e.response.text}")
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))



@app.get("/sessions/{session_id}/artifacts")
async def get_artifacts(session_id: str):
    clean_id = session_id.split("/")[-1]
    
    rows = await db.get_session_artifacts(clean_id)
    result = []
    for r in rows:
        p = Path(r.filepath) if r.filepath else None
        
        result.append({
            "id": r.id,
            "session_id": r.session_id,
            "type": r.type,
            "filename": r.filename, # Чистое имя без префиксов
            "filepath": r.filepath,
            "exists": p.exists() if p else False
        })
    return result

@app.get("/artifacts/download")
async def download_artifact(path: str):
    p = Path(path)
    if p.exists():
        return FileResponse(str(p))
    
    # Fallback: try to find the file by filename in the exporter output directory
    if exporter and p.name:
        for session_dir in exporter.output_dir.iterdir():
            if session_dir.is_dir():
                candidate = session_dir / p.name
                if candidate.exists():
                    print(f">>> Artifact fallback: {path} -> {candidate}")
                    return FileResponse(str(candidate))
    
    raise HTTPException(status_code=404, detail=f"File not found: {path}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8765)
