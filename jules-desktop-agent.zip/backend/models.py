from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

class CreateSessionRequest(BaseModel):
    source_id: str
    prompt: str
    starting_branch: str = "main"
    auto_create_pr: bool = True
    confirm_plan: bool = True

class SendMessageRequest(BaseModel):
    prompt: str

class SessionResponse(BaseModel):
    session_id: str
    status: str
    created_at: datetime

class ActivityResponse(BaseModel):
    session_id: str
    status: str
    activities: List[dict]
    response_text: Optional[str] = None
    patch_available: bool = False
    pr_url: Optional[str] = None

class ArtifactInfo(BaseModel):
    session_id: str
    type: str           # md_response | git_patch
    filename: str
    filepath: str

class SourceInfo(BaseModel):
    id: str
    name: str
    github_url: Optional[str] = None
    default_branch: str = "main"
    branches: List[str] = []

class Config(BaseModel):
    jules_api_key: str
    github_token: str = ""
    output_dir: str
    polling_interval_ms: int = 5000
    theme: str = "dark"
    confirm_plan_before_execution: bool = True
    auto_create_pr: bool = True
    last_source_id: Optional[str] = None
    last_branch: Optional[str] = "main"
