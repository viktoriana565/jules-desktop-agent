import os
from datetime import datetime
from typing import List, Optional
from sqlalchemy import Column, String, Integer, DateTime, ForeignKey, Text, select, update
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker, declarative_base, relationship

Base = declarative_base()

class DB_Source(Base):
    __tablename__ = "sources"
    id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    github_url = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

class DB_Session(Base):
    __tablename__ = "sessions"
    id = Column(String, primary_key=True)
    source_id = Column(String, ForeignKey("sources.id"))
    prompt = Column(Text, nullable=False)
    status = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)
    artifacts = relationship("DB_Artifact", back_populates="session")

class DB_Artifact(Base):
    __tablename__ = "artifacts"
    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String, ForeignKey("sessions.id"))
    type = Column(String) # md_response | git_patch
    filename = Column(String)
    filepath = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    session = relationship("DB_Session", back_populates="artifacts")

class SessionStore:
    def __init__(self, db_path: str = "db.sqlite3"):
        self.engine = create_async_engine(f"sqlite+aiosqlite:///{db_path}")
        self.async_session = sessionmaker(
            self.engine, class_=AsyncSession, expire_on_commit=False
        )

    async def init_db(self):
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

    async def save_source(self, source_id: str, name: str, github_url: str = None):
        async with self.async_session() as session:
            source = DB_Source(id=source_id, name=name, github_url=github_url)
            await session.merge(source)
            await session.commit()

    async def get_sources(self) -> List[DB_Source]:
        async with self.async_session() as session:
            result = await session.execute(select(DB_Source))
            return result.scalars().all()

    async def save_session(self, session_id: str, source_id: str, prompt: str, status: str):
        async with self.async_session() as session:
            db_session = DB_Session(id=session_id, source_id=source_id, prompt=prompt, status=status)
            session.add(db_session)
            await session.commit()

    async def update_session_status(self, session_id: str, status: str):
        async with self.async_session() as session:
            await session.execute(
                update(DB_Session).where(DB_Session.id == session_id).values(status=status)
            )
            if status in ("sessionCompleted", "sessionFailed"):
               await session.execute(
                    update(DB_Session).where(DB_Session.id == session_id).values(completed_at=datetime.utcnow())
                )
            await session.commit()

    async def add_user_message(self, session_id: str, message: str):
        # История сообщений хранится в Jules API (activities).
        # Здесь мы просто обновляем локальный статус, чтобы UI быстрее среагировал.
        await self.update_session_status(session_id, "agentWorking")

    async def get_sessions_history(self) -> List[DB_Session]:
        async with self.async_session() as session:
            result = await session.execute(select(DB_Session).order_by(DB_Session.created_at.desc()))
            return result.scalars().all()

    async def get_session(self, session_id: str) -> Optional[DB_Session]:
        async with self.async_session() as session:
            result = await session.execute(select(DB_Session).where(DB_Session.id == session_id))
            return result.scalars().first()

    async def save_artifact(self, session_id: str, type: str, filename: str, filepath: str):
        async with self.async_session() as session:
            artifact = DB_Artifact(session_id=session_id, type=type, filename=filename, filepath=filepath)
            session.add(artifact)
            await session.commit()

    async def get_session_artifacts(self, session_id: str) -> List[DB_Artifact]:
        async with self.async_session() as session:
            result = await session.execute(select(DB_Artifact).where(DB_Artifact.session_id == session_id))
            return result.scalars().all()
