import httpx
import asyncio
from typing import Optional, List
from models import SourceInfo, ActivityResponse

# Jules API can be slow — 60s timeout for all calls
_TIMEOUT = httpx.Timeout(60.0, connect=10.0)

JULES_BASE_URL = "https://jules.googleapis.com/v1alpha"

class JulesClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.headers = {
            "X-Goog-Api-Key": api_key,
            "Content-Type": "application/json"
        }

    async def list_sources(self) -> List[SourceInfo]:
        """Получить список подключённых GitHub репозиториев"""
        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            response = await client.get(f"{JULES_BASE_URL}/sources", headers=self.headers)
            response.raise_for_status()
            data = response.json()
            sources = []
            for item in data.get("sources", []):
                repo = item.get("githubRepo", {})
                branches = [b.get("displayName") for b in repo.get("branches", [])]
                def_branch = repo.get("defaultBranch", {}).get("displayName", "main")
                
                # Full id should be "github/owner/repo" or similar
                # We can strip "sources/" from the name
                source_id = item["name"]
                if source_id.startswith("sources/"):
                    source_id = source_id[len("sources/"):]
                    
                sources.append(SourceInfo(
                    id=source_id,
                    name=item.get("displayName", source_id.split("/")[-1]),
                    github_url=item.get("githubUrl", ""),
                    default_branch=def_branch,
                    branches=branches
                ))
            return sources

    async def create_session(
        self,
        source_id: str,
        prompt: str,
        starting_branch: str = "main",
        auto_create_pr: bool = True,
        confirm_plan: bool = True
    ) -> dict:
        """Создать новую сессию (задачу) в Jules"""
        # Ensure correct prefix
        if not source_id.startswith("sources/"):
            source_id = f"sources/{source_id}"
            
        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            payload = {
                "sourceContext": {
                    "source": source_id,
                    "githubRepoContext": {
                        "startingBranch": starting_branch
                    }
                },
                "prompt": prompt,
                "requirePlanApproval": confirm_plan
            }
            if auto_create_pr:
                payload["automationMode"] = "AUTO_CREATE_PR"
                
            response = await client.post(f"{JULES_BASE_URL}/sessions", headers=self.headers, json=payload)
            response.raise_for_status()
            return response.json()

    async def get_session(self, session_id: str) -> dict:
        """Получить данные о сессии (статус, детали)"""
        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            response = await client.get(f"{JULES_BASE_URL}/sessions/{session_id}", headers=self.headers)
            response.raise_for_status()
            return response.json()

    async def get_activities(self, session_id: str) -> dict:
        """Получить список активностей сессии"""
        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            response = await client.get(f"{JULES_BASE_URL}/sessions/{session_id}/activities", headers=self.headers)
            response.raise_for_status()
            return response.json()

    async def confirm_plan(self, session_id: str) -> dict:
        """Подтвердить план агента"""
        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            response = await client.post(f"{JULES_BASE_URL}/sessions/{session_id}:approvePlan", headers=self.headers, json={})
            response.raise_for_status()
            return response.json()

    async def send_followup(self, session_id: str, prompt: str) -> dict:
        """
        Продолжить работу в существующей сессии.
        Работает из статусов: COMPLETED, AWAITING_USER_FEEDBACK
        Документация: POST /sessions/{id}:sendMessage → пустой ответ
        """
        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            payload = {"prompt": prompt}
            response = await client.post(
                f"{JULES_BASE_URL}/sessions/{session_id}:sendMessage",
                headers=self.headers,
                json=payload
            )
            response.raise_for_status()
            # Ответ ПУСТОЙ — это норма по документации (SendMessageResponse = {})
            # Агент пришлёт ответ в следующей activity
            return {"status": "message_sent"}

    async def poll_until_complete(
        self,
        session_id: str,
        interval_seconds: float = 5.0,
        max_attempts: int = 120
    ) -> dict:
        """
        Polling активностей до завершения сессии.
        Завершающие статусы: sessionCompleted, sessionFailed
        Возвращает последний snapshot активностей.
        """
        for attempt in range(max_attempts):
            result = await self.get_activities(session_id)
            status = result.get("status", "")
            if status in ("sessionCompleted", "sessionFailed"):
                return result
            await asyncio.sleep(interval_seconds)
        raise TimeoutError(f"Session {session_id} did not complete in time")
